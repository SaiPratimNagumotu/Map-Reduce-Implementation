# Map-Reduce-Implementation
Developed a program to compute many demographic statistics using Hadoop Map/Reduce framework on the US census dataset.  Analyzed performance of the single node cluster on Windows by varying the no of input splits.
